import pyperclip
import time

code_for_all_columns = ""

while True:
    bigcolum = input("นี่คอลั่มที่เท่าไหร่: ")
    if bigcolum.lower() == 'exit':
        break
    bigcolum = int(bigcolum)
    
    print("ใส่ตัวเลือกแต่ละข้อทีละบรรทัด (พิมพ์ 'end' เพื่อจบ):")
    choices = []
    while True:
        line = input()
        if line.lower() == 'end' or line.strip() == '':
            break
        # ดึงตัวเลขในวงเล็บ
        selectchoice = int(line.strip().split('(')[-1].replace(')',''))
        selectchoice = selectchoice + 1
        choices.append(selectchoice)
        

    code_for_all = ""
    for number, selectchoice in enumerate(choices, start=1):
        bigcolumX = bigcolum + 1
        colum = number * 2

        code_template = f'//*[@id="mG61Hd"]/div[2]/div/div[2]/div[{bigcolumX}]/div/div/div[2]/div/div[1]/div/div[{colum}]/span/div[{selectchoice}]/div/div/div[3]/div'

        codeforcopy = f'''    #----- ข้อ {number} -----  
    xpath{number} = '{code_template}'
    option{number} = wait.until(EC.element_to_be_clickable((By.XPATH, xpath{number})))
    option{number}.click()
    time.sleep(0.5)
'''
        code_for_all += codeforcopy

    line = f'    #--------------- คอลั่ม {bigcolum} ---------------\n'
    code_for_all_columns += line + code_for_all

    pyperclip.copy(code_for_all_columns)
    print("---------")
    print("โค้ดทั้งหมดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")
