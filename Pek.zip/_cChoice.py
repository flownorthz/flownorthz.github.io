import random
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

import pyperclip

# รับจำนวนตัวเลือกจากผู้ใช้
number = int(input("Number: "))  # เลขข้อ เช่น 3 -> q3
num_options = 1

# รับข้อความของแต่ละตัวเลือก
options = []
for i in range(1, num_options + 1):
    choice_text = input(f"ใส่คำตอบที่ต้องการเลือก: ").strip()
    if choice_text:  # ตรวจสอบว่าไม่ใช่ค่าว่าง
        options.append(f'//span[text()="{choice_text}"]')

# สร้างตัวแปรตามหมายเลขที่ผู้ใช้ระบุ
q_var = f"q{number}"

# สุ่มเลือก option หนึ่ง
chosen_option = random.choice(options)

# สร้างโค้ดที่ต้องการคัดลอก
generated_code = f"#-------- ข้อ {number} --------\n"
generated_code += f'    wait.until(EC.element_to_be_clickable((By.XPATH, \'{chosen_option}\')))\n'
generated_code += f'    {q_var}_option = driver.find_element(By.XPATH, \'{chosen_option}\')\n'
generated_code += f'    {q_var}_option.click()\n'

# คัดลอกไปยังคลิปบอร์ด
pyperclip.copy(generated_code)

# แสดงผลลัพธ์
print("---------")
print("โค้ดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")
print(generated_code)
