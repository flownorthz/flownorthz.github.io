import pyperclip

print("---------")
link = input("link Form: ")

code = f"""import random
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from webdriver_manager.chrome import ChromeDriverManager

try:
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)

    link = "{link}"
    driver.get(link)

    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.TAG_NAME, 'form')))
    #----------

    



    #----- กดส่ง -----


except Exception as e:
    print("เกิดข้อผิดพลาด:", e)
    print("โปรแกรมจะไม่ปิด รอให้คุณกด Enter เพื่อออก")
    input()  # รอให้ผู้ใช้กด Enter ก่อนปิด

finally:
    # ถ้าต้องการให้ปิด driver หลังกด Enter ให้เปิดบรรทัดนี้
    # driver.quit()
    pass

"""

pyperclip.copy(code)  # คัดลอกข้อความไปยังคลิปบอร์ด
print("---------")
print("โค้ดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")