import subprocess

while True:
    print("---------")
    print("1.Info 2.FiveChoice 3.Next 4.Send 5.Start 6.Exit")
    print("---------")
    choose = int(input("Choose Type: "))


    if choose == 1:
        subprocess.run(['python', '_cInfo.py'])
    elif choose == 2:
        subprocess.run(['python', '_cFiveChoice.py'])
    elif choose == 3:
        subprocess.run(['python', '_cNext.py'])
    elif choose == 4:
        subprocess.run(['python', '_cSend.py'])
    elif choose == 5:
        subprocess.run(['python', '_cStarts.py'])
    elif choose == 6:
        print("Exiting the program.")
        break
    else:
        print("Invalid choice. Please select a valid option.")



