import pyperclip

# รับข้อมูลทั้งหมดเป็นหลายบรรทัด
print("กรอกข้อมูลแต่ละบรรทัด: ")
lines = []
while True:
    line = input()
    if line.strip() == "":
        break
    lines.append(line.strip())

# สร้างโค้ด Python ที่จะใช้ข้อมูลเหล่านี้
questions_list = ",\n        ".join(f'"{line}"' for line in lines)

code = f"""questions = [
        {questions_list}
    ]

    for text in questions:
        option = wait.until(EC.element_to_be_clickable((By.XPATH, f'//span[text()="{{text}}"]')))
        option.click()
        time.sleep(0.5)
"""

# คัดลอกไปคลิปบอร์ด
pyperclip.copy(code)
print("---------")
print("โค้ดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")
