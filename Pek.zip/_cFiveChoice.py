import pyperclip
import time

code_for_all_columns = ""

while True:
    bigcolum = input("นี่คอลั่มที่เท่าไหร่: ")
    if bigcolum.lower() == 'exit':
        break
    bigcolum = int(bigcolum)

    num_questions = int(input("มีจำนวนกี่ข้อในคอลั่มนี้: "))

    code_for_all = ""
    for number in range(1, num_questions + 1):
        selectchoice = int(input(f"ข้อ {number}: เลือกช้อยคำตอบ: ")) + 1
        
        # ทำให้ colum เป็นเลขคู่
        bigcolumX = bigcolum + 1
        colum = number * 2

        code_template = f'//*[@id="mG61Hd"]/div[2]/div/div[2]/div[{bigcolumX}]/div/div/div[2]/div/div[1]/div/div[{colum}]/span/div[{selectchoice}]/div/div/div[3]/div'

        codeforcopy = f'''    #----- ข้อ {number} -----  
    xpath{number} = '{code_template}'
    option{number} = wait.until(EC.element_to_be_clickable((By.XPATH, xpath{number})))
    option{number}.click()
    time.sleep(0.5)
'''
        code_for_all += codeforcopy

    line = f'    #--------------- คอลั่ม {bigcolum} ---------------\n'
    code_for_all_columns += line + code_for_all
    # คัดลอกโค้ดทั้งหมดไปคลิปบอร์ด
    pyperclip.copy(code_for_all_columns)
    print("---------")
    print("โค้ดทั้งหมดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")


