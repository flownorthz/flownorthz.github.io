import pyperclip

code = """    #----- กดส่ง -----
    submit_button = driver.find_element(By.XPATH, '//span[text()="ส่ง" or text()="Submit"]')
    submit_button.click()

    time.sleep(2)
    print("ส่งฟอร์มเรียบร้อยแล้ว")
"""

pyperclip.copy(code)  # คัดลอกข้อความไปยังคลิปบอร์ด
print("---------")
print("โค้ดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")
