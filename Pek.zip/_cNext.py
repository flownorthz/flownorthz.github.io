import pyperclip

code = """    # กดปุ่ม "ถัดไป" 
    next_button = wait.until(EC.element_to_be_clickable((By.XPATH, '//span[text()="ถัดไป"]')))
    next_button.click()
    time.sleep(3)
"""

pyperclip.copy(code)  # คัดลอกข้อความไปยังคลิปบอร์ด
print("---------")
print("โค้ดถูกคัดลอกไปยังคลิปบอร์ดแล้ว! 🎉")
